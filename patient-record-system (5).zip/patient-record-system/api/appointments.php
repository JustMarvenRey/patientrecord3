<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";

class Appointment {

    // Queue number = this appointment's place among the NON-cancelled appointments of the same doctor
    // at the same date and time, ordered by who SUBMITTED first (CreatedAt, then AppointmentID).
    // Calculated when read, so it stays correct when someone cancels (the others move up).
    // Several patients may book the same time slot; the queue decides who is consulted first.
    private $queueSql = "(CASE WHEN a.Status = 'Cancelled' THEN NULL ELSE (
                SELECT COUNT(*) + 1 FROM APPOINTMENT q
                WHERE q.UserID = a.UserID AND q.AppointmentDate = a.AppointmentDate
                  AND q.AppointmentTime = a.AppointmentTime AND q.Status <> 'Cancelled'
                  AND q.AppointmentID <> a.AppointmentID
                  AND (COALESCE(q.CreatedAt, '1970-01-01 00:00:00') < COALESCE(a.CreatedAt, '1970-01-01 00:00:00')
                       OR (COALESCE(q.CreatedAt, '1970-01-01 00:00:00') = COALESCE(a.CreatedAt, '1970-01-01 00:00:00')
                           AND q.AppointmentID < a.AppointmentID))
              ) END)";

    // All appointments — Admin/Staff view (full list, all doctors)
    function getAllAppointments() {
        include "connection-pdo.php";
        $sql = "SELECT
                    a.AppointmentID,
                    a.AppointmentDate,
                    a.AppointmentTime,
                    a.Reason,
                    a.Status,
                    a.Notes,
                    a.ChiefComplaint,
                    a.Symptoms,
                    a.CreatedAt,
                    {$this->queueSql} AS QueueNumber,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    p.PatientID,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                    u.UserID,
                    (SELECT COUNT(*) FROM VITAL_SIGN v
                      WHERE v.AppointmentID = a.AppointmentID AND v.Status = 'Active') AS HasVitals,
                    (a.ChiefComplaint IS NOT NULL AND a.ChiefComplaint <> '') AS HasIntake
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC, QueueNumber ASC";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Appointments for a specific doctor (Doctor view)
    function getAppointmentsByDoctor($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT
                    a.AppointmentID,
                    a.AppointmentDate,
                    a.AppointmentTime,
                    a.Reason,
                    a.Status,
                    a.Notes,
                    a.ChiefComplaint,
                    a.Symptoms,
                    a.CreatedAt,
                    {$this->queueSql} AS QueueNumber,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    p.PatientID,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                    u.UserID,
                    (SELECT COUNT(*) FROM VITAL_SIGN v
                      WHERE v.AppointmentID = a.AppointmentID AND v.Status = 'Active') AS HasVitals,
                    (a.ChiefComplaint IS NOT NULL AND a.ChiefComplaint <> '') AS HasIntake
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                WHERE a.UserID = :userId
                ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC, QueueNumber ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":userId", $json['userId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Single appointment detail
    function getAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT
                    a.*,
                    {$this->queueSql} AS QueueNumber,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                WHERE a.AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Get all active doctors for the doctor dropdown
    function getActiveDoctors() {
        include "connection-pdo.php";
        $sql = "SELECT u.UserID,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                       GROUP_CONCAT(s.SpecializationName ORDER BY s.SpecializationName SEPARATOR ', ') AS Specializations
                FROM USERS u
                JOIN ROLE r ON u.RoleID = r.RoleID
                LEFT JOIN DOCTOR_SPECIALIZATION ds ON ds.UserID = u.UserID
                LEFT JOIN SPECIALIZATION s ON s.SpecializationID = ds.SpecializationID
                WHERE r.RoleName = 'Doctor' AND u.Status = 'Active'
                GROUP BY u.UserID, u.LastName, u.FirstName
                ORDER BY u.LastName, u.FirstName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // The PATIENT record a logged-in Patient account is linked to (null for anyone else).
    // The patient is ALWAYS taken from the account on the server - never from the request.
    private function myPatientId($conn, $actingUserId) {
        if (empty($actingUserId)) return null;
        $st = $conn->prepare("SELECT u.PatientID FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Patient'
                                AND u.PatientID IS NOT NULL");
        $st->bindValue(":id", $actingUserId);
        $st->execute();
        $pid = $st->fetchColumn();
        return $pid === false ? null : (int)$pid;
    }

    // Patient: my own appointments (all statuses)
    function getMyAppointments($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $pid = $this->myPatientId($conn, $json['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);

        $st = $conn->prepare("SELECT a.AppointmentID, a.AppointmentDate, a.AppointmentTime, a.Reason, a.Status, a.CreatedAt,
                                     {$this->queueSql} AS QueueNumber,
                                     CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                              FROM APPOINTMENT a JOIN USERS u ON a.UserID = u.UserID
                              WHERE a.PatientID = :pid
                              ORDER BY a.AppointmentDate DESC, a.AppointmentTime DESC, QueueNumber ASC");
        $st->bindValue(":pid", $pid);
        $st->execute();
        return json_encode($st->fetchAll(PDO::FETCH_ASSOC));
    }

    // Patient: book an appointment for myself online (same validation + the same-patient
    // guard as staff booking, because it goes through insertAppointment).
    function bookMyAppointment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $pid = $this->myPatientId($conn, $in['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);
        if (trim($in['reason'] ?? '') === '') return Validator::fail("Please tell us the reason for your visit.");

        return $this->insertAppointment(json_encode([
            "patientId"       => $pid,
            "userId"          => $in['userId'] ?? null,
            "appointmentDate" => $in['appointmentDate'] ?? null,
            "appointmentTime" => $in['appointmentTime'] ?? null,
            "reason"          => $in['reason'] ?? null,
            "notes"           => $in['notes'] ?? null,
        ]));
    }

    // Patient: cancel one of MY appointments. Only a still-Scheduled one in the future.
    function cancelMyAppointment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $pid = $this->myPatientId($conn, $in['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);
        if ($e = Validator::badId($in, ['appointmentId'])) return Validator::fail($e);

        $st = $conn->prepare("SELECT Status, AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS T
                              FROM APPOINTMENT WHERE AppointmentID = :id AND PatientID = :pid");
        $st->bindValue(":id", $in['appointmentId']);
        $st->bindValue(":pid", $pid);
        $st->execute();
        $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return Validator::fail("That appointment was not found.");
        if ($a['Status'] !== 'Scheduled') return Validator::fail("Only a scheduled appointment can be cancelled.");
        if ($a['AppointmentDate'] < date('Y-m-d') || Validator::timePassedToday($a['AppointmentDate'], $a['T']))
            return Validator::fail("This appointment's time has already passed.");

        $up = $conn->prepare("UPDATE APPOINTMENT SET Status = 'Cancelled' WHERE AppointmentID = :id AND PatientID = :pid AND Status = 'Scheduled'");
        $up->bindValue(":id", $in['appointmentId']);
        $up->bindValue(":pid", $pid);
        $up->execute();
        return json_encode($up->rowCount() > 0 ? 1 : 0);
    }

    // True when $date (YYYY-MM-DD) is a real date and is today or later.
    private function isTodayOrFuture($date) {
        $d = DateTime::createFromFormat('Y-m-d', $date ?? '');
        if (!$d || $d->format('Y-m-d') !== $date) return false;
        return $date >= date('Y-m-d');
    }

    // Create — available to Staff, Doctor, and Patient (all roles)
    // Many patients MAY book the same doctor at the same date and time - they are put in a queue by
    // who submitted first (see $queueSql). The guard: the same PATIENT can't have more than one
    // appointment on the same DAY. Scheduled and Completed ones count; Cancelled and No-Show don't.
    private function findConflict($conn, $json, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM APPOINTMENT
                WHERE PatientID = :who AND AppointmentDate = :d AND Status IN ('Scheduled', 'Completed')";
        if ($excludeId !== null) $sql .= " AND AppointmentID != :id";
        $st = $conn->prepare($sql);
        $st->bindValue(":who", $json['patientId']);
        $st->bindValue(":d", $json['appointmentDate']);
        if ($excludeId !== null) $st->bindValue(":id", $excludeId);
        $st->execute();
        if ((int)$st->fetchColumn() > 0) {
            return "That patient already has an appointment on {$json['appointmentDate']}. A patient can only have one appointment per day.";
        }
        return null;
    }

    function insertAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        list($err, $json) = Validator::run("appointment", $json);
        if ($err) return Validator::fail($err);

        // The patient must exist and be Active; the doctor must be an Active user with the Doctor role.
        $pc = $conn->prepare("SELECT COUNT(*) FROM PATIENT WHERE PatientID = :id AND Status = 'Active'");
        $pc->bindValue(":id", $json['patientId']); $pc->execute();
        if ((int)$pc->fetchColumn() === 0) return Validator::fail("That patient is not available. Please select an active patient.");
        $dc = $conn->prepare("SELECT COUNT(*) FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Doctor'");
        $dc->bindValue(":id", $json['userId']); $dc->execute();
        if ((int)$dc->fetchColumn() === 0) return Validator::fail("That doctor is not available. Please select an active doctor.");
        if ($e = Validator::timePassedToday($json['appointmentDate'], $json['appointmentTime'])) return Validator::fail($e);
        if ($e = $this->findConflict($conn, $json)) return Validator::fail($e);

        // CreatedAt = the moment the request was submitted (shown as "Requested"; lists are sorted by appointment time).
        $sql = "INSERT INTO APPOINTMENT
                    (PatientID, UserID, AppointmentDate, AppointmentTime, Reason, Notes, Status, CreatedAt)
                VALUES
                    (:patientId, :userId, :appointmentDate, :appointmentTime, :reason, :notes, 'Scheduled', NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":patientId",       $json['patientId']);
        $stmt->bindParam(":userId",          $json['userId']);
        $stmt->bindParam(":appointmentDate", $json['appointmentDate']);
        $stmt->bindParam(":appointmentTime", $json['appointmentTime']);
        $stmt->bindParam(":reason",          $json['reason']);
        $stmt->bindParam(":notes",           $json['notes']);
        $stmt->execute();

        if ($stmt->rowCount() > 0 && !empty($json['returnId'])) {
            // Lets the Staff UI go straight on to the intake
            return json_encode(["appointmentId" => (int)$conn->lastInsertId()]);
        }
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Update — Admin and Staff only
    function updateAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $cur = $conn->prepare("SELECT AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS T FROM APPOINTMENT WHERE AppointmentID = :id");
        $cur->bindParam(":id", $json['appointmentId']);
        $cur->execute();
        $old = $cur->fetch(PDO::FETCH_ASSOC);
        if (!$old) return Validator::fail("That appointment no longer exists.");
        $currentDate = $old['AppointmentDate'];
        // Only enforce "not in the past" when the date/time is being changed, so an old
        // appointment can still be marked Completed / No-Show.
        $dateChanged = ($json['appointmentDate'] ?? null) !== $currentDate;
        $timeChanged = substr($json['appointmentTime'] ?? '', 0, 5) !== $old['T'];
        $relax = $dateChanged ? [] : ['notPast'];
        list($err, $json) = Validator::run("appointment", $json, ['relax' => $relax]);
        if ($err) return Validator::fail($err);
        if (empty($json['status'])) return Validator::fail("Status is required.");
        if (($dateChanged || $timeChanged) && ($e = Validator::timePassedToday($json['appointmentDate'], $json['appointmentTime']))) return Validator::fail($e);
        if ($json['status'] === 'Scheduled' && ($e = $this->findConflict($conn, $json, $json['appointmentId']))) return Validator::fail($e);

        $sql = "UPDATE APPOINTMENT SET
                    PatientID       = :patientId,
                    UserID          = :userId,
                    AppointmentDate = :appointmentDate,
                    AppointmentTime = :appointmentTime,
                    Reason          = :reason,
                    Notes           = :notes,
                    Status          = :status
                WHERE AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":patientId",       $json['patientId']);
        $stmt->bindParam(":userId",          $json['userId']);
        $stmt->bindParam(":appointmentDate", $json['appointmentDate']);
        $stmt->bindParam(":appointmentTime", $json['appointmentTime']);
        $stmt->bindParam(":reason",          $json['reason']);
        $stmt->bindParam(":notes",           $json['notes']);
        $stmt->bindParam(":status",          $json['status']);
        $stmt->bindParam(":appointmentId",   $json['appointmentId']);
        $stmt->execute();

        return Validator::saved($conn, $stmt, 'APPOINTMENT', 'AppointmentID', $json['appointmentId']);
    }

    // Cancel — Admin and Staff only (soft status change)
    function cancelAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $sql = "UPDATE APPOINTMENT SET Status = 'Cancelled' WHERE AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Staff record the intake: Reason, Chief Complaint and Symptoms. The doctor sees
    // these automatically in the consultation and does not re-enter them.
    function saveIntake($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        $roleStmt = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                                    WHERE u.UserID = :id AND u.Status = 'Active'");
        $roleStmt->bindValue(":id", $json['actingUserId'] ?? null);
        $roleStmt->execute();
        if ($roleStmt->fetchColumn() !== 'Staff') return json_encode(["error" => "forbidden"]);

                list($err, $json) = Validator::run("intake", $json, ['nullEmpty' => true]);
        if ($err) return Validator::fail($err);
$cur = $conn->prepare("SELECT Status FROM APPOINTMENT WHERE AppointmentID = :id");
        $cur->bindValue(":id", $json['appointmentId'] ?? null);
        $cur->execute();
        $status = $cur->fetchColumn();
        if ($status === false) return json_encode(["error" => "not_found"]);
        if ($status === 'Cancelled') return json_encode(["error" => "appointment_cancelled"]);

        $stmt = $conn->prepare("UPDATE APPOINTMENT SET
                                    Reason = :reason, ChiefComplaint = :cc, Symptoms = :symptoms
                                WHERE AppointmentID = :id");
        $stmt->bindValue(":reason",   $json['reason']         ?? null);
        $stmt->bindValue(":cc",       $json['chiefComplaint'] ?? null);
        $stmt->bindValue(":symptoms", $json['symptoms']       ?? null);
        $stmt->bindValue(":id",       $json['appointmentId']);
        $stmt->execute();
        return json_encode(1); // rowCount is 0 when nothing changed - still a success
    }

    // Restore a cancelled appointment back to Scheduled (Admin "Restore" button).
    // Only touches rows that are currently Cancelled.
    function restoreAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $row = $conn->prepare("SELECT PatientID, UserID, AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS AppointmentTime
                               FROM APPOINTMENT WHERE AppointmentID = :id AND Status = 'Cancelled'");
        $row->bindValue(":id", $json['appointmentId']);
        $row->execute();
        $r = $row->fetch(PDO::FETCH_ASSOC);
        if ($r) {
            $data = ['patientId' => $r['PatientID'], 'userId' => $r['UserID'],
                     'appointmentDate' => $r['AppointmentDate'], 'appointmentTime' => $r['AppointmentTime']];
            if ($r['AppointmentDate'] < Validator::today() || Validator::timePassedToday($r['AppointmentDate'], $r['AppointmentTime']))
                return Validator::fail("This appointment's date and time have already passed, so it can't be set back to Scheduled. Use Edit to change the date instead.");
            if ($e = $this->findConflict($conn, $data, $json['appointmentId'])) return Validator::fail($e);
        }
        $sql = "UPDATE APPOINTMENT SET Status = 'Scheduled'
                WHERE AppointmentID = :appointmentId AND Status = 'Cancelled'";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$appt = new Appointment();
switch ($operation) {
    case "getAllAppointments":       echo $appt->getAllAppointments();           break;
    case "getAppointmentsByDoctor": echo $appt->getAppointmentsByDoctor($json); break;
    case "getAppointment":          echo $appt->getAppointment($json);          break;
    case "getActiveDoctors":        echo $appt->getActiveDoctors();             break;
    case "insertAppointment":       echo $appt->insertAppointment($json);       break;
    case "updateAppointment":       echo $appt->updateAppointment($json);       break;
    case "cancelAppointment":       echo $appt->cancelAppointment($json);       break;
    case "restoreAppointment":      echo $appt->restoreAppointment($json);      break;
    case "saveIntake":              echo $appt->saveIntake($json);              break;
    case "getMyAppointments":       echo $appt->getMyAppointments($json);       break;
    case "bookMyAppointment":       echo $appt->bookMyAppointment($json);       break;
    case "cancelMyAppointment":     echo $appt->cancelMyAppointment($json);     break;
}
?>
