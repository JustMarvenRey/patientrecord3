<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";

// When a doctor can't make it, Staff (or Admin) send the patient a CHANGE REQUEST for a scheduled
// appointment. It recommends one or both of:
//   - another doctor with a similar specialization (same date and time), and/or
//   - a new date (and time).
// The patient answers from "My Appointments": accept the doctor, accept the date, or decline.
// Accepting updates the appointment; the patient is always taken from the logged-in account.
class ChangeRequest {

    private function roleOf($conn, $userId) {
        if (empty($userId)) return null;
        $st = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active'");
        $st->bindValue(":id", $userId);
        $st->execute();
        $r = $st->fetchColumn();
        return $r === false ? null : $r;
    }

    private function isStaffOrAdmin($conn, $userId) {
        return in_array($this->roleOf($conn, $userId), ['Staff', 'Admin'], true);
    }

    private function myPatientId($conn, $userId) {
        if (empty($userId)) return null;
        $st = $conn->prepare("SELECT u.PatientID FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Patient'
                                AND u.PatientID IS NOT NULL");
        $st->bindValue(":id", $userId);
        $st->execute();
        $pid = $st->fetchColumn();
        return $pid === false ? null : (int)$pid;
    }

    private function validDate($d) {
        $x = DateTime::createFromFormat('Y-m-d', $d ?? '');
        return $x && $x->format('Y-m-d') === $d;
    }

    // Active doctors that share at least one specialization with $doctorId (not $doctorId itself).
    private function similarDoctors($conn, $doctorId) {
        $sql = "SELECT u.UserID,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                       (SELECT GROUP_CONCAT(s2.SpecializationName ORDER BY s2.SpecializationName SEPARATOR ', ')
                          FROM DOCTOR_SPECIALIZATION d2
                          JOIN SPECIALIZATION s2 ON s2.SpecializationID = d2.SpecializationID
                         WHERE d2.UserID = u.UserID) AS Specializations
                FROM USERS u
                JOIN ROLE r ON r.RoleID = u.RoleID
                WHERE r.RoleName = 'Doctor' AND u.Status = 'Active' AND u.UserID <> :doc
                  AND EXISTS (SELECT 1
                                FROM DOCTOR_SPECIALIZATION a
                                JOIN DOCTOR_SPECIALIZATION b ON b.SpecializationID = a.SpecializationID
                               WHERE a.UserID = u.UserID AND b.UserID = :doc2)
                ORDER BY u.LastName, u.FirstName";
        $st = $conn->prepare($sql);
        $st->bindValue(":doc", $doctorId);
        $st->bindValue(":doc2", $doctorId);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    // Does this patient already have a Scheduled / Completed appointment on $date (other than $exceptId)?
    private function patientBusyOn($conn, $patientId, $date, $exceptId) {
        $st = $conn->prepare("SELECT COUNT(*) FROM APPOINTMENT
                              WHERE PatientID = :p AND AppointmentDate = :d AND AppointmentID <> :id
                                AND Status IN ('Scheduled', 'Completed')");
        $st->bindValue(":p", $patientId);
        $st->bindValue(":d", $date);
        $st->bindValue(":id", $exceptId);
        $st->execute();
        return (int)$st->fetchColumn() > 0;
    }

    private function hasPending($conn, $appointmentId) {
        $st = $conn->prepare("SELECT COUNT(*) FROM APPOINTMENT_CHANGE_REQUEST WHERE AppointmentID = :id AND Status = 'Pending'");
        $st->bindValue(":id", $appointmentId);
        $st->execute();
        return (int)$st->fetchColumn() > 0;
    }

    // Validates and inserts ONE request. Returns null on success or an error message.
    private function createOne($conn, $appt, $in, $byUserId) {
        $reason = trim($in['reason'] ?? '');
        $sugDoc = !empty($in['suggestedUserId']) ? (int)$in['suggestedUserId'] : null;
        $sugDate = !empty($in['suggestedDate']) ? $in['suggestedDate'] : null;
        $sugTime = !empty($in['suggestedTime']) ? substr($in['suggestedTime'], 0, 5) : null;

        if ($appt['Status'] !== 'Scheduled') return "Only a scheduled appointment can be changed.";
        if ($this->hasPending($conn, $appt['AppointmentID'])) return "This appointment already has a pending request.";
        if ($reason === '') return "Please write a short message for the patient.";
        if (strlen($reason) > 255) return "The message is too long (255 characters at most).";
        if (!$sugDoc && !$sugDate) return "Recommend another doctor, a new date, or both.";

        if ($sugDoc) {
            $ok = false;
            foreach ($this->similarDoctors($conn, $appt['UserID']) as $d) {
                if ((int)$d['UserID'] === $sugDoc) { $ok = true; break; }
            }
            if (!$ok) return "The recommended doctor must be an active doctor with a similar specialization.";
        }
        if ($sugDate) {
            if (!$this->validDate($sugDate)) return "The suggested date is not valid.";
            if ($sugDate < Validator::today()) return "The suggested date can't be in the past.";
            if ($sugDate === $appt['AppointmentDate'] && !$sugTime) return "Please choose a different date for the new appointment.";
            if (!$sugTime) $sugTime = substr($appt['AppointmentTime'], 0, 5);
            if ($e = Validator::timePassedToday($sugDate, $sugTime)) return $e;
            if ($this->patientBusyOn($conn, $appt['PatientID'], $sugDate, $appt['AppointmentID']))
                return "That patient already has an appointment on $sugDate. A patient can only have one appointment per day.";
        } else {
            $sugTime = null;
        }

        $ins = $conn->prepare("INSERT INTO APPOINTMENT_CHANGE_REQUEST
                (AppointmentID, Reason, SuggestedUserID, SuggestedDate, SuggestedTime, Status, CreatedBy, CreatedAt)
                VALUES (:a, :r, :u, :d, :t, 'Pending', :by, NOW())");
        $ins->bindValue(":a", $appt['AppointmentID']);
        $ins->bindValue(":r", $reason);
        $ins->bindValue(":u", $sugDoc);
        $ins->bindValue(":d", $sugDate);
        $ins->bindValue(":t", $sugTime);
        $ins->bindValue(":by", $byUserId);
        $ins->execute();
        return null;
    }

    private function getAppt($conn, $appointmentId) {
        $st = $conn->prepare("SELECT AppointmentID, PatientID, UserID, AppointmentDate, AppointmentTime, Status
                              FROM APPOINTMENT WHERE AppointmentID = :id");
        $st->bindValue(":id", $appointmentId);
        $st->execute();
        return $st->fetch(PDO::FETCH_ASSOC);
    }

    // ── Staff / Admin ────────────────────────────────────────────────────────

    // Doctors with a similar specialization. Give appointmentId OR doctorId.
    function getSimilarDoctors($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if (!$this->isStaffOrAdmin($conn, $in['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);
        $doctorId = $in['doctorId'] ?? null;
        if (!$doctorId && !empty($in['appointmentId'])) {
            $a = $this->getAppt($conn, $in['appointmentId']);
            $doctorId = $a ? $a['UserID'] : null;
        }
        if (!$doctorId) return Validator::fail("That appointment no longer exists.");
        return json_encode($this->similarDoctors($conn, $doctorId));
    }

    // All requests (newest first) - the Appointments page uses them to show each appointment's status.
    function getRequests($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if (!$this->isStaffOrAdmin($conn, $in['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);
        $st = $conn->prepare("SELECT c.RequestID, c.AppointmentID, c.Reason, c.Status, c.ResponseChoice, c.CreatedAt, c.RespondedAt,
                                     c.SuggestedUserID, c.SuggestedDate, c.SuggestedTime,
                                     CONCAT(d.LastName, ', ', d.FirstName) AS SuggestedDoctorName
                              FROM APPOINTMENT_CHANGE_REQUEST c
                              LEFT JOIN USERS d ON d.UserID = c.SuggestedUserID
                              ORDER BY c.RequestID DESC");
        $st->execute();
        return json_encode($st->fetchAll(PDO::FETCH_ASSOC));
    }

    // One appointment.
    function createRequest($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $by = $in['actingUserId'] ?? null;
        if (!$this->isStaffOrAdmin($conn, $by)) return json_encode(["error" => "forbidden"]);
        if ($e = Validator::badId($in, ['appointmentId'])) return Validator::fail($e);
        $appt = $this->getAppt($conn, $in['appointmentId']);
        if (!$appt) return Validator::fail("That appointment no longer exists.");
        if ($e = $this->createOne($conn, $appt, $in, $by)) return Validator::fail($e);
        return json_encode(1);
    }

    // "Doctor unavailable": one request for every still-scheduled appointment of that doctor on that date.
    function createBulkRequests($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $by = $in['actingUserId'] ?? null;
        if (!$this->isStaffOrAdmin($conn, $by)) return json_encode(["error" => "forbidden"]);
        if ($e = Validator::badId($in, ['doctorId'])) return Validator::fail($e);
        if (!$this->validDate($in['date'] ?? '')) return Validator::fail("Please choose the date the doctor is unavailable.");

        $st = $conn->prepare("SELECT a.AppointmentID, a.PatientID, a.UserID, a.AppointmentDate, a.AppointmentTime, a.Status,
                                     CONCAT(p.LastName, ', ', p.FirstName) AS PatientName
                              FROM APPOINTMENT a JOIN PATIENT p ON p.PatientID = a.PatientID
                              WHERE a.UserID = :d AND a.AppointmentDate = :date AND a.Status = 'Scheduled'
                              ORDER BY a.AppointmentTime");
        $st->bindValue(":d", $in['doctorId']);
        $st->bindValue(":date", $in['date']);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return Validator::fail("That doctor has no scheduled appointments on that date.");

        $created = 0; $skipped = [];
        foreach ($rows as $appt) {
            // A bulk "new date" keeps each patient's own time unless it would fall on the same day
            $one = $in; unset($one['suggestedTime']);
            if (!empty($in['suggestedDate']) && $in['suggestedDate'] === $appt['AppointmentDate']) {
                return Validator::fail("The suggested date must be different from the day the doctor is unavailable.");
            }
            $err = $this->createOne($conn, $appt, $one, $by);
            if ($err) $skipped[] = ["patient" => $appt['PatientName'], "why" => $err];
            else $created++;
        }
        return json_encode(["created" => $created, "skipped" => $skipped]);
    }

    function withdrawRequest($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if (!$this->isStaffOrAdmin($conn, $in['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);
        if ($e = Validator::badId($in, ['requestId'])) return Validator::fail($e);
        $up = $conn->prepare("UPDATE APPOINTMENT_CHANGE_REQUEST SET Status = 'Withdrawn', RespondedAt = NOW()
                              WHERE RequestID = :id AND Status = 'Pending'");
        $up->bindValue(":id", $in['requestId']);
        $up->execute();
        return $up->rowCount() > 0 ? json_encode(1) : Validator::fail("That request is no longer pending.");
    }

    // ── Patient ──────────────────────────────────────────────────────────────

    // My pending requests (only for my own, still-scheduled appointments)
    function getMyRequests($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $pid = $this->myPatientId($conn, $in['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);
        $st = $conn->prepare("SELECT c.RequestID, c.AppointmentID, c.Reason, c.SuggestedUserID, c.SuggestedDate, c.SuggestedTime, c.CreatedAt,
                                     a.AppointmentDate, a.AppointmentTime,
                                     CONCAT(cur.LastName, ', ', cur.FirstName) AS CurrentDoctorName,
                                     CONCAT(sug.LastName, ', ', sug.FirstName) AS SuggestedDoctorName,
                                     (SELECT GROUP_CONCAT(s.SpecializationName ORDER BY s.SpecializationName SEPARATOR ', ')
                                        FROM DOCTOR_SPECIALIZATION ds JOIN SPECIALIZATION s ON s.SpecializationID = ds.SpecializationID
                                       WHERE ds.UserID = c.SuggestedUserID) AS SuggestedSpecializations
                              FROM APPOINTMENT_CHANGE_REQUEST c
                              JOIN APPOINTMENT a ON a.AppointmentID = c.AppointmentID
                              JOIN USERS cur ON cur.UserID = a.UserID
                              LEFT JOIN USERS sug ON sug.UserID = c.SuggestedUserID
                              WHERE a.PatientID = :pid AND c.Status = 'Pending' AND a.Status = 'Scheduled'
                              ORDER BY a.AppointmentDate, a.AppointmentTime");
        $st->bindValue(":pid", $pid);
        $st->execute();
        return json_encode($st->fetchAll(PDO::FETCH_ASSOC));
    }

    // choice: "doctor" | "date" | "decline"
    function respondMyRequest($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $pid = $this->myPatientId($conn, $in['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);
        if ($e = Validator::badId($in, ['requestId'])) return Validator::fail($e);
        $choice = $in['choice'] ?? '';
        if (!in_array($choice, ['doctor', 'date', 'decline'], true)) return Validator::fail("Please choose one of the options.");

        $st = $conn->prepare("SELECT c.*, a.PatientID, a.UserID, a.AppointmentDate, a.AppointmentTime, a.Status AS ApptStatus
                              FROM APPOINTMENT_CHANGE_REQUEST c JOIN APPOINTMENT a ON a.AppointmentID = c.AppointmentID
                              WHERE c.RequestID = :id AND a.PatientID = :pid");
        $st->bindValue(":id", $in['requestId']);
        $st->bindValue(":pid", $pid);
        $st->execute();
        $req = $st->fetch(PDO::FETCH_ASSOC);
        if (!$req) return Validator::fail("That request was not found.");
        if ($req['Status'] !== 'Pending') return Validator::fail("This request has already been answered or withdrawn.");
        if ($req['ApptStatus'] !== 'Scheduled') return Validator::fail("This appointment is no longer scheduled.");

        if ($choice === 'doctor') {
            if (empty($req['SuggestedUserID'])) return Validator::fail("No other doctor was recommended.");
            $dc = $conn->prepare("SELECT COUNT(*) FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                                  WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Doctor'");
            $dc->bindValue(":id", $req['SuggestedUserID']); $dc->execute();
            if ((int)$dc->fetchColumn() === 0) return Validator::fail("That doctor is no longer available. Please contact the clinic.");
            $up = $conn->prepare("UPDATE APPOINTMENT SET UserID = :u WHERE AppointmentID = :a AND Status = 'Scheduled'");
            $up->bindValue(":u", $req['SuggestedUserID']);
            $up->bindValue(":a", $req['AppointmentID']);
            $up->execute();
        } elseif ($choice === 'date') {
            if (empty($req['SuggestedDate'])) return Validator::fail("No new date was recommended.");
            $time = substr($req['SuggestedTime'] ?: $req['AppointmentTime'], 0, 5);
            if ($req['SuggestedDate'] < Validator::today()) return Validator::fail("That date has already passed. Please contact the clinic.");
            if ($e = Validator::timePassedToday($req['SuggestedDate'], $time)) return Validator::fail($e);
            if ($this->patientBusyOn($conn, $pid, $req['SuggestedDate'], $req['AppointmentID']))
                return Validator::fail("You already have an appointment on {$req['SuggestedDate']}. Please contact the clinic.");
            $up = $conn->prepare("UPDATE APPOINTMENT SET AppointmentDate = :d, AppointmentTime = :t
                                  WHERE AppointmentID = :a AND Status = 'Scheduled'");
            $up->bindValue(":d", $req['SuggestedDate']);
            $up->bindValue(":t", $time);
            $up->bindValue(":a", $req['AppointmentID']);
            $up->execute();
        }

        $newStatus = $choice === 'decline' ? 'Declined' : 'Accepted';
        $fin = $conn->prepare("UPDATE APPOINTMENT_CHANGE_REQUEST SET Status = :s, ResponseChoice = :c, RespondedAt = NOW()
                               WHERE RequestID = :id AND Status = 'Pending'");
        $fin->bindValue(":s", $newStatus);
        $fin->bindValue(":c", $choice);
        $fin->bindValue(":id", $in['requestId']);
        $fin->execute();
        return json_encode(1);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'] ?? '';
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'] ?? '';
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$cr = new ChangeRequest();
switch ($operation) {
    case "getSimilarDoctors":    echo $cr->getSimilarDoctors($json);    break;
    case "getRequests":          echo $cr->getRequests($json);          break;
    case "createRequest":        echo $cr->createRequest($json);        break;
    case "createBulkRequests":   echo $cr->createBulkRequests($json);   break;
    case "withdrawRequest":      echo $cr->withdrawRequest($json);      break;
    case "getMyRequests":        echo $cr->getMyRequests($json);        break;
    case "respondMyRequest":     echo $cr->respondMyRequest($json);     break;
    default: echo json_encode(["error" => "unknown operation"]);
}
