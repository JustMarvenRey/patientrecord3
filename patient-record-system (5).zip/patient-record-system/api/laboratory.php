<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";
require_once __DIR__ . "/billing-total.php";

class Laboratory {

    // Get all laboratory records for a consultation
    function getLaboratoriesByConsultation($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT l.LaboratoryID, l.ConsultationID, l.TestID, l.TestDate,
                       l.Result, l.ReferenceRange, l.Status, l.Price,
                       lt.TestName, lt.NormalRange, lt.Description AS TestDescription
                FROM LABORATORY l
                JOIN LABORATORY_TEST lt ON l.TestID = lt.TestID
                WHERE l.ConsultationID = :consultationId AND l.Status = 'Active'
                ORDER BY l.TestDate DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":consultationId", $json['consultationId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Get a single laboratory record
    function getLaboratory($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT l.LaboratoryID, l.ConsultationID, l.TestID, l.TestDate,
                       l.Result, l.ReferenceRange, l.Status,
                       lt.TestName, lt.NormalRange, lt.Description AS TestDescription
                FROM LABORATORY l
                JOIN LABORATORY_TEST lt ON l.TestID = lt.TestID
                WHERE l.LaboratoryID = :laboratoryId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":laboratoryId", $json['laboratoryId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Insert a new laboratory record
    function insertLaboratory($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['consultationId'])) return Validator::fail($e);
        list($err, $json) = Validator::run("lab", $json, ['nullEmpty' => true]);
        if ($err) return Validator::fail($err);
        // The price is copied from the price list NOW, so later price changes don't alter this charge
        $sql = "INSERT INTO LABORATORY
                    (ConsultationID, TestID, TestDate, Result, ReferenceRange, Price, Status)
                VALUES
                    (:consultationId, :testId, :testDate, :result, :referenceRange,
                     (SELECT Price FROM LABORATORY_TEST WHERE TestID = :testId2), 'Active')";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":consultationId", $json['consultationId']);
        $stmt->bindParam(":testId",         $json['testId']);
        $stmt->bindParam(":testId2",        $json['testId']);
        $stmt->bindParam(":testDate",       $json['testDate']);
        $stmt->bindValue(":result",         $json['result']         ?? null);
        $stmt->bindValue(":referenceRange", $json['referenceRange'] ?? null);
        $stmt->execute();
        $ok = $stmt->rowCount() > 0;
        if ($ok) recalcBillForConsultation($conn, $json['consultationId']);
        return json_encode($ok ? 1 : 0);
    }

    // Update an existing laboratory record
    function updateLaboratory($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['laboratoryId'])) return Validator::fail($e);
        list($err, $json) = Validator::run("lab", $json, ['nullEmpty' => true]);
        if ($err) return Validator::fail($err);
        // Choosing a DIFFERENT test re-prices the charge; just editing the result keeps the original price
        $sql = "UPDATE LABORATORY SET
                    Price          = IF(TestID <> :testIdNew, (SELECT Price FROM LABORATORY_TEST WHERE TestID = :testIdPrice), Price),
                    TestID         = :testId,
                    TestDate       = :testDate,
                    Result         = :result,
                    ReferenceRange = :referenceRange
                WHERE LaboratoryID = :laboratoryId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":testIdNew",      $json['testId']);
        $stmt->bindParam(":testIdPrice",    $json['testId']);
        $stmt->bindParam(":testId",         $json['testId']);
        $stmt->bindParam(":testDate",       $json['testDate']);
        $stmt->bindValue(":result",         $json['result']         ?? null);
        $stmt->bindValue(":referenceRange", $json['referenceRange'] ?? null);
        $stmt->bindParam(":laboratoryId",   $json['laboratoryId']);
        $stmt->execute();
        $this->refreshBillFor($conn, $json['laboratoryId']);
        return Validator::saved($conn, $stmt, 'LABORATORY', 'LaboratoryID', $json['laboratoryId']);
    }

    // Soft delete a laboratory record
    function removeLaboratory($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "UPDATE LABORATORY SET Status = 'Inactive' WHERE LaboratoryID = :laboratoryId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":laboratoryId", $json['laboratoryId']);
        $stmt->execute();
        $this->refreshBillFor($conn, $json['laboratoryId']);
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // After a lab record changes, refresh the total of its consultation's bill (if it has one)
    private function refreshBillFor($conn, $laboratoryId) {
        $q = $conn->prepare("SELECT ConsultationID FROM LABORATORY WHERE LaboratoryID = :id");
        $q->bindValue(":id", (int)$laboratoryId, PDO::PARAM_INT);
        $q->execute();
        $cid = $q->fetchColumn();
        if ($cid !== false) recalcBillForConsultation($conn, $cid);
    }

    // Get all active tests for the dropdown
    function getActiveTests() {
        include "connection-pdo.php";
        $sql = "SELECT TestID, TestName, NormalRange, Description, Price
                FROM LABORATORY_TEST
                WHERE Status = 'Active'
                ORDER BY TestName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$lab = new Laboratory();
switch ($operation) {
    case "getLaboratoriesByConsultation": echo $lab->getLaboratoriesByConsultation($json); break;
    case "getLaboratory":                 echo $lab->getLaboratory($json);                 break;
    case "insertLaboratory":              echo $lab->insertLaboratory($json);              break;
    case "updateLaboratory":              echo $lab->updateLaboratory($json);              break;
    case "removeLaboratory":              echo $lab->removeLaboratory($json);              break;
    case "getActiveTests":                echo $lab->getActiveTests();                     break;
}
?>
