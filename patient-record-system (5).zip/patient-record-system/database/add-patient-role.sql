-- ============================================================
-- Patient logins: lets a patient sign in and view ONLY their own medical records.
-- The app also does this automatically (api/auto-migrate.php) the first time it
-- connects, so running this by hand in phpMyAdmin is optional. Safe to run once.
-- ============================================================
USE patient_record_system;

-- 1. Each Patient login points at one PATIENT record (one login per patient).
ALTER TABLE USERS ADD COLUMN PatientID INT NULL DEFAULT NULL;
ALTER TABLE USERS ADD CONSTRAINT uq_users_patient UNIQUE (PatientID);
ALTER TABLE USERS ADD CONSTRAINT fk_users_patient FOREIGN KEY (PatientID) REFERENCES PATIENT(PatientID);

-- 2. The Patient role.
INSERT INTO ROLE (RoleName, Description, Status)
SELECT 'Patient', 'Patients who can view their own medical records', 'Active'
WHERE NOT EXISTS (SELECT 1 FROM ROLE WHERE RoleName = 'Patient');

-- 3. Example account (optional) - change PatientID to a real, Active patient first:
-- INSERT INTO USERS (RoleID, Username, Password, FirstName, LastName, PatientID, Status)
-- SELECT r.RoleID, 'patient1', 'patient123', p.FirstName, p.LastName, p.PatientID, 'Active'
-- FROM ROLE r JOIN PATIENT p ON p.PatientID = 1 WHERE r.RoleName = 'Patient' LIMIT 1;

-- 4. Online payments (patients paying their own bills). Only the method and a reference
--    number are stored - never card numbers.
CREATE TABLE IF NOT EXISTS PAYMENT (
  PaymentID INT AUTO_INCREMENT PRIMARY KEY,
  BillID INT NOT NULL,
  Amount DECIMAL(10,2) NOT NULL,
  Method VARCHAR(30) NOT NULL,
  ReferenceNo VARCHAR(40) NOT NULL,
  Channel VARCHAR(10) NOT NULL DEFAULT 'Online',
  PaidByUserID INT NULL,
  PaidAt DATETIME NOT NULL,
  UNIQUE KEY uq_payment_ref (ReferenceNo),
  KEY idx_payment_bill (BillID),
  CONSTRAINT fk_payment_bill FOREIGN KEY (BillID) REFERENCES BILLING(BillID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
