// home-analytics.js — role-specific analytics on the dashboard (home.html).
//   Admin  → clinic-wide overview
//   Doctor → their OWN patients / appointments / consultations
//   Staff  → front desk + billing (today's queue, collections, unpaid bills)
// Data comes from api/analytics.php, which decides the role (and which doctor) on the server.
// Charts are drawn with Chart.js (loaded from the CDN in home.html).

const BASE_API = sessionStorage.getItem("baseAPIUrl") || "http://localhost/patient-record-system/api";

// Meaning-colours: the same in every theme / accent (green = done or paid, amber = waiting, red = problem)
const OK = "#4caf50", AMBER = "#f9a825", RED = "#d9534f", GREY = "#9aa5a0", BLUE = "#2f7fb8";
const STATUS_COLORS = { Completed: OK, Scheduled: BLUE, Cancelled: RED, "No-Show": AMBER };
const BILL_COLORS = { Paid: OK, Pending: AMBER, Cancelled: RED };

// Accent-colours: follow the chosen theme (read from the CSS variables each time we draw)
const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const C = { strong: "#006400", mid: "#4caf50", pale: "#a5d6a7" };
const refreshTheme = () => {
  C.strong = css("--prs-green-text"); C.mid = css("--prs-chart-mid"); C.pale = css("--prs-chart-pale");
  Chart.defaults.color = css("--text-muted");
  Chart.defaults.borderColor = css("--border");
  Chart.defaults.elements.arc.borderColor = css("--card-bg");
};

const peso = (v) =>
  `₱ ${(parseFloat(v) || 0).toLocaleString("en-PH", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
const pct = (n, d) => (d > 0 ? `${Math.round((n / d) * 100)}%` : "—");
const short = (s, n = 28) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

// ── Chart helpers ───────────────────────────────────────────────────────────
const charts = {};
const draw = (id, config) => {
  charts[id]?.destroy();
  const canvas = document.getElementById(id);
  const box = canvas.parentElement;
  box.querySelector(".chart-empty")?.remove();
  canvas.style.display = "";
  if (!config.data.datasets.some((d) => d.data.some((v) => v > 0))) {
    canvas.style.display = "none";
    box.insertAdjacentHTML("beforeend", `<div class="chart-empty">No data for this period</div>`);
    return;
  }
  charts[id] = new Chart(canvas, config);
};

const monthSpan = (start, end) => {
  const out = [];
  let [y, m] = start.split("-").map(Number);
  const [ey, em] = end.split("-").map(Number);
  while (y < ey || (y === ey && m <= em)) {
    out.push(`${y}-${String(m).padStart(2, "0")}`);
    if (++m > 12) { m = 1; y++; }
  }
  return out;
};
const monthLabel = (ym) => {
  const [y, m] = ym.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleString("en-US", { month: "short", year: "2-digit" });
};

const baseOpts = { responsive: true, maintainAspectRatio: false };
const legendBottom = { legend: { position: "bottom", labels: { boxWidth: 12, font: { size: 11 } } } };
const countAxis = { beginAtZero: true, ticks: { precision: 0 } };
const STATUSES = ["Completed", "Scheduled", "No-Show", "Cancelled"];

// ── Chart builders (each returns a Chart.js config for the data `d`; `ctx` has months/labels) ──
const BUILDERS = {
  "chart-appts": (d, { months, labels }) => ({
    type: "bar",
    data: {
      labels,
      datasets: STATUSES.map((s) => ({
        label: s, backgroundColor: STATUS_COLORS[s],
        data: months.map((m) => Number(d.apptByMonth.find((r) => r.ym === m && r.Status === s)?.n || 0)),
      })),
    },
    options: { ...baseOpts, plugins: legendBottom, scales: { x: { stacked: true }, y: { ...countAxis, stacked: true } } },
  }),

  "chart-status": (d) => ({
    type: "doughnut",
    data: {
      labels: STATUSES,
      datasets: [{ data: [d.kpi.completed, d.kpi.scheduled, d.kpi.noShow, d.kpi.cancelled], backgroundColor: STATUSES.map((s) => STATUS_COLORS[s]) }],
    },
    options: { ...baseOpts, cutout: "62%", plugins: legendBottom },
  }),

  // Admin: revenue by month  |  Staff: collections by month (same shape, different source key)
  "chart-money": (d, { months, labels }) => {
    const rows = d.revenueByMonth || d.collectionsByMonth || [];
    const of = (s) => months.map((m) => Number(rows.find((r) => r.ym === m && r.Status === s)?.total || 0));
    return {
      type: "bar",
      data: { labels, datasets: [
        { label: "Paid", backgroundColor: OK, data: of("Paid") },
        { label: "Pending", backgroundColor: AMBER, data: of("Pending") },
      ] },
      options: {
        ...baseOpts,
        plugins: { ...legendBottom, tooltip: { callbacks: { label: (c) => `${c.dataset.label}: ${peso(c.parsed.y)}` } } },
        scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { callback: (v) => peso(v) } } },
      },
    };
  },

  "chart-gender": (d) => ({
    type: "doughnut",
    data: { labels: d.gender.map((r) => r.Gender), datasets: [{ data: d.gender.map((r) => Number(r.n)), backgroundColor: [C.strong, C.mid, BLUE, GREY, C.pale] }] },
    options: { ...baseOpts, cutout: "62%", plugins: legendBottom },
  }),

  "chart-ages": (d) => {
    const bands = ["0-12", "13-17", "18-39", "40-59", "60+"];
    return {
      type: "bar",
      data: { labels: bands, datasets: [{ label: "Patients", backgroundColor: C.mid, data: bands.map((b) => Number(d.ages.find((r) => r.band === b)?.n || 0)) }] },
      options: { ...baseOpts, plugins: { legend: { display: false } }, scales: { y: countAxis } },
    };
  },

  "chart-diagnoses": (d) => rankingConfig(d.topDiagnoses, (r) => `${r.ICD10Code} ${short(r.DiagnosisName, 24)}`, C.strong, "Cases"),
  "chart-medicines": (d) => rankingConfig(d.topMedicines, (r) => short(r.MedicineName), BLUE, "Prescriptions"),

  "chart-doctors": (d) => ({
    type: "bar",
    data: { labels: d.perDoctor.map((r) => r.DoctorName), datasets: [
      { label: "Appointments", backgroundColor: C.pale, data: d.perDoctor.map((r) => Number(r.appointments)) },
      { label: "Consultations", backgroundColor: C.strong, data: d.perDoctor.map((r) => Number(r.consultations)) },
    ] },
    options: { ...baseOpts, plugins: legendBottom, scales: { y: countAxis } },
  }),

  "chart-weekday": (d) => {
    const names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    return {
      type: "bar",
      data: { labels: names, datasets: [{ label: "Appointments", backgroundColor: BLUE, data: names.map((_, i) => Number(d.weekday.find((r) => Number(r.d) === i)?.n || 0)) }] },
      options: { ...baseOpts, plugins: { legend: { display: false } }, scales: { y: countAxis } },
    };
  },

  "chart-billstatus": (d) => {
    const order = ["Paid", "Pending", "Cancelled"];
    return {
      type: "doughnut",
      data: { labels: order, datasets: [{ data: order.map((s) => Number(d.billStatus.find((r) => r.Status === s)?.n || 0)), backgroundColor: order.map((s) => BILL_COLORS[s]) }] },
      options: { ...baseOpts, cutout: "62%", plugins: legendBottom },
    };
  },

  "chart-aging": (d) => {
    const bands = ["0-7 days", "8-30 days", "31+ days"];
    const row = (b) => d.pendingAging.find((r) => r.band === b);
    return {
      type: "bar",
      data: { labels: bands, datasets: [{ label: "Unpaid bills", backgroundColor: ["#81c784", AMBER, RED], data: bands.map((b) => Number(row(b)?.n || 0)) }] },
      options: {
        ...baseOpts,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => `${c.parsed.y} bill(s) · ${peso(row(bands[c.dataIndex])?.total)}` } } },
        scales: { y: countAxis },
      },
    };
  },
};

function rankingConfig(rows, labelFn, color, name) {
  return {
    type: "bar",
    data: { labels: rows.map(labelFn), datasets: [{ label: name, data: rows.map((r) => Number(r.n)), backgroundColor: color }] },
    options: { ...baseOpts, indexAxis: "y", plugins: { legend: { display: false } }, scales: { x: countAxis } },
  };
}

// ── Per-role layouts: what each role sees ───────────────────────────────────
// col = Bootstrap column classes for the chart card.
const L8 = "col-lg-8", L4 = "col-lg-4", L6 = "col-lg-6";
const LAYOUTS = {
  Admin: {
    heading: "Clinic analytics",
    kpis: (k) => [
      ["👥", "green", k.activePatients, "Active patients", `${k.patientsSeen} seen in period`],
      ["📅", "blue", k.appointments, "Appointments", `${k.scheduled} upcoming`],
      ["🩺", "purple", k.consultations, "Consultations", `${k.activeDoctors} active doctors`],
      ["💳", "amber", peso(k.revenuePaid), "Revenue collected", `${peso(k.revenuePending)} pending (${k.pendingCount} bills)`],
    ],
    charts: [
      ["chart-appts", "Appointments by month", L8], ["chart-status", "Appointment status", L4],
      ["chart-money", "Revenue by month", L8], ["chart-gender", "Patients by gender", L4],
      ["chart-diagnoses", "Top diagnoses", L6], ["chart-medicines", "Most prescribed medicines", L6],
      ["chart-doctors", "Doctor workload", L8], ["chart-ages", "Patients by age group", L4],
    ],
  },
  Doctor: {
    heading: "My practice",
    kpis: (k) => [
      ["📅", "blue", k.today, "My appointments today", `${k.upcoming} upcoming in total`],
      ["⏳", "amber", k.awaiting, "Awaiting consultation", "Scheduled, due today or earlier"],
      ["🩺", "purple", k.consultations, "Consultations", "in the selected period"],
      ["👥", "green", k.patientsSeen, "Patients seen", "distinct patients, selected period"],
    ],
    charts: [
      ["chart-appts", "My appointments by month", L8], ["chart-status", "My appointment status", L4],
      ["chart-diagnoses", "Diagnoses I record most", L6], ["chart-medicines", "Medicines I prescribe most", L6],
      ["chart-weekday", "My busiest weekdays", L6], ["chart-ages", "My patients by age group", L6],
    ],
  },
  Staff: {
    heading: "Front desk & billing",
    kpis: (k) => [
      ["📅", "blue", k.today, "Appointments today", `${k.upcoming} upcoming in total`],
      ["🧾", "purple", k.unbilled, "Consultations to bill", "no bill created yet"],
      ["⚠️", "amber", peso(k.pending), "Unpaid bills", `${k.pendingCount} pending bill(s)`],
      ["💵", "green", peso(k.collected), "Collected", `${k.paidCount} paid bill(s), selected period`],
    ],
    charts: [
      ["chart-appts", "Appointments by month", L8], ["chart-status", "Appointment status", L4],
      ["chart-money", "Collections by month", L8], ["chart-billstatus", "Bills by status", L4],
      ["chart-weekday", "Busiest weekdays", L4], ["chart-aging", "Unpaid bills by age", L4],
      ["chart-doctors", "Appointments per doctor", L4],
    ],
  },
};

const kpiCard = ([icon, bg, value, label, sub]) => `
  <div class="col-6 col-lg-3">
    <div class="stat-card">
      <div class="stat-icon si-${bg}">${icon}</div>
      <div><div class="stat-value">${value}</div><div class="stat-label">${label}</div>
      ${sub ? `<div class="stat-label" style="font-size:.7rem">${sub}</div>` : ""}</div>
    </div>
  </div>`;

let lastData = null;
const render = (d) => {
  const layout = LAYOUTS[d.role];
  if (!layout) return;
  lastData = d;
  refreshTheme();
  document.getElementById("analytics-heading").textContent = layout.heading;
  document.getElementById("analytics-kpis").innerHTML = layout.kpis(d.kpi).map(kpiCard).join("");

  const k = d.kpi;
  const closed = k.completed + k.cancelled + k.noShow;
  document.getElementById("analytics-rates").innerHTML =
    `Completion rate <strong>${pct(k.completed, closed)}</strong> · ` +
    `Cancellation rate <strong>${pct(k.cancelled, closed)}</strong> · ` +
    `No-show rate <strong>${pct(k.noShow, closed)}</strong>`;

  // (Re)build the chart grid for this role
  document.getElementById("analytics-grid").innerHTML = layout.charts.map(([id, title, col]) =>
    `<div class="${col}"><div class="chart-card"><h6>${title}</h6><div class="chart-box"><canvas id="${id}"></canvas></div></div></div>`).join("");
  Object.keys(charts).forEach((id) => { charts[id].destroy(); delete charts[id]; });

  // Month axis (quiet months still show as zero)
  const allMonths = [...(d.apptByMonth || []), ...(d.revenueByMonth || []), ...(d.collectionsByMonth || [])].map((r) => r.ym).sort();
  let months = [];
  if (d.start) {
    const now = new Date();
    const end = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const last = allMonths.length && allMonths[allMonths.length - 1] > end ? allMonths[allMonths.length - 1] : end;
    months = monthSpan(d.start.slice(0, 7), last);
  } else if (allMonths.length) {
    months = monthSpan(allMonths[0], allMonths[allMonths.length - 1]);
  }
  const ctx = { months, labels: months.map(monthLabel) };

  layout.charts.forEach(([id]) => draw(id, BUILDERS[id](d, ctx)));
};

const load = async () => {
  const status = document.getElementById("analytics-status");
  const user = JSON.parse(sessionStorage.getItem("currentUser"));
  status.textContent = "Loading…";
  try {
    const res = await axios.get(`${BASE_API}/analytics.php`, {
      params: {
        operation: "getDashboardAnalytics",
        json: JSON.stringify({ actingUserId: user.UserID, months: Number(document.getElementById("analytics-range").value) }),
      },
    });
    if (res.data?.error) {
      status.textContent = res.data.error === "forbidden" ? "Analytics aren't available for your account." : "Could not load analytics.";
      return;
    }
    status.textContent = `Updated ${new Date().toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" })}`;
    render(res.data);
  } catch (e) {
    console.error(e);
    status.textContent = "Could not load analytics. Is the server running?";
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const raw = sessionStorage.getItem("currentUser");
  if (!raw || !LAYOUTS[JSON.parse(raw).RoleName]) return; // unknown role: section stays hidden
  if (typeof Chart === "undefined") return;                // CDN blocked / offline
  document.getElementById("analytics-section").style.display = "";
  document.getElementById("analytics-range").addEventListener("change", load);
  document.getElementById("analytics-refresh").addEventListener("click", load);
  // Theme changed (mode / accent / device setting): redraw from the data we already have
  document.addEventListener("prs-theme-change", () => { if (lastData) render(lastData); });
  load();
});
