import { cmpText, cmpNum, sortBySelect } from "./sort-utils.js?v=20261107";
import { viewModal } from "./modules-specializations/view.js?v=20261107";
import { updateModal } from "./modules-specializations/update.js?v=20261107";
import { deleteModal } from "./modules-specializations/delete.js?v=20261107";

const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const SORTS = {
  "name-asc":     (a, b) => cmpText(a.SpecializationName, b.SpecializationName),
  "name-desc":    (a, b) => cmpText(b.SpecializationName, a.SpecializationName),
  "doctors-desc": (a, b) => cmpNum(b.DoctorCount, a.DoctorCount) || cmpText(a.SpecializationName, b.SpecializationName),
  "doctors-asc":  (a, b) => cmpNum(a.DoctorCount, b.DoctorCount) || cmpText(a.SpecializationName, b.SpecializationName),
  "status-asc":   (a, b) => cmpText(a.Status, b.Status) || cmpText(a.SpecializationName, b.SpecializationName),
};

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("sort-by").addEventListener("change", () => displaySpecializations());
  displaySpecializations();

  document.getElementById("btn-submit").addEventListener("click", () => {
    insertSpecialization();
  });

  document.getElementById("show-inactive").addEventListener("change", () => {
    displaySpecializations();
  });
});

const displaySpecializations = async () => {
  const response = await axios.get(`${baseApiUrl}/specializations.php`, {
    params: { operation: "getAllSpecializations" },
  });
  if (response.status == 200) {
    displaySpecializationsTable(response.data);
  } else {
    alert("Error!");
  }
};

const displaySpecializationsTable = (specializations) => {
  const showInactive = document.getElementById("show-inactive").checked;
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");

  const thead = document.createElement("thead");
  thead.innerHTML = `
    <tr>
      <th>SPECIALIZATION NAME</th>
      <th>DESCRIPTION</th>
      <th>DOCTORS</th>
      <th>STATUS</th>
      <th>ACTION</th>
    </tr>
  `;
  table.appendChild(thead);

  const tbody = document.createElement("tbody");

  sortBySelect(specializations, SORTS)
    .filter((spec) => showInactive || spec.Status !== "Inactive")
    .forEach((spec) => {
      const doctorCount = Number(spec.DoctorCount ?? 0);
      const isActive = spec.Status !== "Inactive";
      let row = document.createElement("tr");
      if (!isActive) row.classList.add("table-secondary");

      row.innerHTML = `
        <td>${spec.SpecializationName}</td>
        <td>${spec.Description ?? ""}</td>
        <td><span class="badge ${doctorCount > 0 ? "bg-info text-dark" : "bg-light text-dark"}">${doctorCount}</span></td>
        <td>
          <span class="badge ${isActive ? "bg-success" : "bg-secondary"}">${isActive ? "Active" : "Inactive"}</span>
        </td>
        <td>
          <button type="button" class="btn btn-primary btn-sm btn-view">View</button>
          <button type="button" class="btn btn-success btn-sm btn-update">Edit</button>
          ${
            isActive
              ? `<button type="button" class="btn btn-danger btn-sm btn-delete">Deactivate</button>`
              : `<button type="button" class="btn btn-warning btn-sm btn-restore">Restore</button>`
          }
        </td>
      `;
      tbody.appendChild(row);

      row.querySelector(".btn-view").addEventListener("click", () => {
        viewModal(spec.SpecializationID);
      });

      row.querySelector(".btn-update").addEventListener("click", () => {
        updateModal(spec.SpecializationID, displaySpecializations);
      });

      row.querySelector(".btn-delete")?.addEventListener("click", () => {
        deleteModal(spec.SpecializationID, displaySpecializations);
      });

      row.querySelector(".btn-restore")?.addEventListener("click", () => {
        restoreSpecialization(spec.SpecializationID);
      });
    });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

const restoreSpecialization = async (specializationId) => {
  const response = await axios.get(`${baseApiUrl}/specializations.php`, {
    params: {
      operation: "restoreSpecialization",
      json: JSON.stringify({ specializationId }),
    },
  });
  if (response.data == 1) {
    displaySpecializations();
    alert("Specialization restored!");
  } else {
    alert("ERROR");
  }
};

const insertSpecialization = async () => {
  const jsonData = {
    name: document.getElementById("specialization-name").value.trim(),
    description: document.getElementById("description").value,
  };
  if (!Validate.ok("specialization", jsonData)) return;

  if (!jsonData.name) {
    alert("Please fill in the Specialization Name.");
    return;
  }

  const formData = new FormData();
  formData.append("operation", "insertSpecialization");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({
    url: `${baseApiUrl}/specializations.php`,
    method: "POST",
    data: formData,
  });

  if (response.data == 1) {
    clearForm();
    displaySpecializations();
    alert("Specialization successfully saved!");
  } else if (response.data?.error === "duplicate") {
    alert(`"${jsonData.name}" already exists in the list (it may be deactivated - turn on "Show inactive specializations" to restore it).`);
  } else {
    alert("ERROR");
  }
};

const clearForm = () => {
  document.getElementById("specialization-name").value = "";
  document.getElementById("description").value = "";
};
