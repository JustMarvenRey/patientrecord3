export const deleteModal = async (specializationId, refreshDisplay) => {
  document.getElementById("blank-modal-title").innerText = "Confirm Deactivate";

  const specialization = await getSpecializationDetails(specializationId);
  const s = specialization[0];

  let myHtml = `
    <p>This specialization may already be assigned to one or more doctors, so it will be
    <strong>deactivated</strong> (soft delete) rather than removed. Doctors who already have it
    are unaffected; it will just be hidden from the list when assigning specializations.
    You can restore it later.</p>
    <table class="table table-sm">
      <tr>
        <td>Name</td>
        <td>${s.SpecializationName}</td>
      </tr>
    </table>
  `;
  document.getElementById("blank-main-div").innerHTML = myHtml;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
    <div class="btn-group w-100" role="group">
      <button type="button" class="btn btn-danger btn-sm w-100 me-2 btn-delete">Deactivate</button>
      <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
    </div>
  `;

  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  modalFooter.querySelector(".btn-delete").addEventListener("click", async () => {
    if ((await deleteSpecializationRecord(s.SpecializationID)) == 1) {
      refreshDisplay();
      alert("Specialization has been deactivated!");
      myModal.hide();
    } else {
      alert("ERROR");
    }
  });

  myModal.show();
};

const getSpecializationDetails = async (specializationId) => {
  const params = {
    operation: "getSpecialization",
    json: JSON.stringify({ specializationId: specializationId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/specializations.php`, {
    params: params,
  });
  return response.data;
};

const deleteSpecializationRecord = async (specializationId) => {
  const params = {
    operation: "deleteSpecialization",
    json: JSON.stringify({ specializationId: specializationId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/specializations.php`, {
    params: params,
  });
  return response.data;
};
