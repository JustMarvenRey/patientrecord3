// Patient self-service: see my bills and pay them online.
// DEMO CHECKOUT - no real money moves (see api/billing.php payMyBill). Card numbers are never collected.
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");
const actingUserId = currentUser?.UserID;

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const peso = (n) => `₱ ${(parseFloat(n) || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const METHODS = [
  { value: "GCash", label: "GCash", icon: "📱" },
  { value: "Maya", label: "Maya", icon: "📱" },
  { value: "Credit/Debit Card", label: "Credit / Debit Card", icon: "💳" },
  { value: "Online Banking", label: "Online Banking", icon: "🏦" },
];
const STATUS_BADGE = { Pending: "bg-warning text-dark", Paid: "bg-success", Cancelled: "bg-secondary" };
const ERRORS = {
  already_paid: "This bill has already been paid.",
  not_payable: "This bill can't be paid online right now.",
  not_found: "That bill was not found.",
  invalid_method: "Please choose a payment method.",
  payment_failed: "The payment could not be completed. You were not charged. Please try again.",
  forbidden: "Your account can't pay bills.",
};

let bills = [];

const showAlert = (message, type = "danger") => {
  const box = document.getElementById("bills-alert");
  box.className = `alert alert-${type}`;
  box.textContent = message;
};

document.addEventListener("DOMContentLoaded", () => {
  if (!currentUser || currentUser.RoleName !== "Patient") return;
  loadBills();
});

const loadBills = async () => {
  const list = document.getElementById("bills-list");
  try {
    const res = await axios.get(`${baseApiUrl}/billing.php`, {
      params: { operation: "getMyBills", json: JSON.stringify({ actingUserId }) },
    });
    if (!Array.isArray(res.data)) throw new Error("bad response");
    bills = res.data;
    renderBills();
  } catch (e) {
    list.innerHTML = `<div class="form-card text-center text-muted py-4">Could not load your bills.</div>`;
  }
};

const renderBills = () => {
  const list = document.getElementById("bills-list");
  if (bills.length === 0) {
    list.innerHTML = `<div class="form-card text-center text-muted py-4">You have no bills yet.</div>`;
    return;
  }
  const unpaid = bills.filter((b) => b.Status === "Pending");
  const due = unpaid.reduce((sum, b) => sum + (parseFloat(b.TotalAmount) || 0), 0);

  list.innerHTML = `
    <p class="text-muted mb-3" style="font-size:.85rem;">
      ${unpaid.length ? `<strong>${unpaid.length}</strong> unpaid bill${unpaid.length > 1 ? "s" : ""} · <strong>${peso(due)}</strong> due` : "You're all paid up. Thank you!"}
    </p>
    ${bills.map((b) => {
      const fees = (b.fees || []).map((f) =>
        `<tr><td>${esc(f.Description || "Professional fee")} <span class="text-muted">(${esc(f.DoctorName)})</span></td><td class="text-end">${peso(f.FeeAmount)}</td></tr>`
      ).join("");
      const labs = (b.labs || []).map((l) =>
        `<tr><td>Laboratory: ${esc(l.TestName)}</td><td class="text-end">${peso(l.Price)}</td></tr>`
      ).join("");
      return `
      <div class="section-card mb-3">
        <div class="d-flex align-items-start justify-content-between mb-2">
          <div>
            <strong>Bill #${esc(b.BillID)}</strong>
            <span class="badge ${STATUS_BADGE[b.Status] || "bg-secondary"} ms-2">${esc(b.Status)}</span>
            <div class="text-muted" style="font-size:.8rem;">Billed ${esc(b.BillDate)} · Consultation ${esc(b.ConsultationDate)} · ${esc(b.DoctorName)}</div>
          </div>
          <div class="text-end"><div style="font-size:1.15rem;font-weight:700;">${peso(b.TotalAmount)}</div></div>
        </div>
        ${fees || labs ? `<table class="table table-sm mb-2" style="font-size:.82rem;"><tbody>${fees}${labs}</tbody></table>` : ""}
        ${b.Status === "Paid" && b.ReferenceNo
          ? `<div class="text-muted" style="font-size:.8rem;">Paid ${esc(b.PaidAt)} via ${esc(b.PaymentMethod)} · Ref ${esc(b.ReferenceNo)}</div>`
          : ""}
        ${b.Status === "Pending"
          ? `<button type="button" class="btn btn-success btn-sm btn-pay" data-id="${esc(b.BillID)}">Pay Online</button>`
          : ""}
        ${b.Status === "Paid"
          ? `<a class="btn btn-outline-secondary btn-sm mt-1" href="receipt.html?bill=${esc(b.BillID)}">View Receipt</a>`
          : ""}
      </div>`;
    }).join("")}`;
  list.querySelectorAll(".btn-pay").forEach((btn) => btn.addEventListener("click", () => openPayModal(btn.dataset.id)));
};

const openPayModal = (billId) => {
  const bill = bills.find((b) => String(b.BillID) === String(billId));
  if (!bill) return;
  document.getElementById("pay-modal-title").textContent = `Pay Bill #${bill.BillID}`;
  document.getElementById("pay-modal-body").innerHTML = `
    <div class="mb-3">
      <div class="text-muted" style="font-size:.8rem;">Amount to pay</div>
      <div style="font-size:1.5rem;font-weight:700;">${peso(bill.TotalAmount)}</div>
    </div>
    <div class="mb-2" style="font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;">Payment method</div>
    ${METHODS.map((m, i) => `
      <div class="form-check mb-1">
        <input class="form-check-input" type="radio" name="pay-method" id="pm-${i}" value="${esc(m.value)}" />
        <label class="form-check-label" for="pm-${i}">${m.icon} ${esc(m.label)}</label>
      </div>`).join("")}
    <div class="alert alert-info mt-3 mb-0" style="font-size:.8rem;">
      <strong>Demo checkout.</strong> No real money is charged and no card details are collected.
    </div>
    <div id="pay-error" class="text-danger mt-2" style="font-size:.85rem;"></div>`;
  document.getElementById("pay-modal-footer").innerHTML = `
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
    <button type="button" class="btn btn-success btn-sm" id="btn-confirm-pay">Pay ${peso(bill.TotalAmount)}</button>`;

  const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById("pay-modal"));
  document.getElementById("btn-confirm-pay").addEventListener("click", () => confirmPay(bill, modal));
  modal.show();
};

const confirmPay = async (bill, modal) => {
  const errBox = document.getElementById("pay-error");
  errBox.textContent = "";
  const method = document.querySelector("input[name='pay-method']:checked")?.value;
  if (!method) { errBox.textContent = ERRORS.invalid_method; return; }

  const btn = document.getElementById("btn-confirm-pay");
  btn.disabled = true;
  btn.textContent = "Processing...";
  try {
    const formData = new FormData();
    formData.append("operation", "payMyBill");
    formData.append("json", JSON.stringify({ actingUserId, billId: bill.BillID, method }));
    const res = await axios({ url: `${baseApiUrl}/billing.php`, method: "POST", data: formData });
    if (res.data?.paid) {
      showReceipt(bill, res.data, modal);
      await loadBills();
      return;
    }
    errBox.textContent = ERRORS[res.data?.error] || "The payment could not be completed.";
    if (res.data?.error === "already_paid") await loadBills();
  } catch (e) {
    errBox.textContent = "Could not reach the server. You were not charged. Please try again.";
  }
  btn.disabled = false;
  btn.textContent = `Pay ${peso(bill.TotalAmount)}`;
};

const showReceipt = (bill, result, modal) => {
  document.getElementById("pay-modal-title").textContent = "Payment successful";
  document.getElementById("pay-modal-body").innerHTML = `
    <div class="text-center py-2">
      <div style="font-size:2.5rem;">✅</div>
      <div style="font-size:1.25rem;font-weight:700;">${peso(result.amount)}</div>
      <div class="text-muted" style="font-size:.85rem;">Bill #${esc(bill.BillID)} paid via ${esc(result.method)}</div>
      <div class="mt-2" style="font-size:.85rem;">Reference no.<br/><strong>${esc(result.referenceNo)}</strong></div>
    </div>`;
  document.getElementById("pay-modal-footer").innerHTML = `
    <a class="btn btn-outline-secondary btn-sm" href="receipt.html?bill=${esc(bill.BillID)}">View Receipt</a>
    <button type="button" class="btn btn-success btn-sm" data-bs-dismiss="modal">Done</button>`;
};
